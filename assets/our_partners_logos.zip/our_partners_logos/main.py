import os 

files = os.listdir('./assets/our_partners_logos') ;

print(files)